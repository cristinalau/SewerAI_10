CREATE OR REPLACE TRIGGER trg_wo_reqcomp_to_stg
/*----------------------------------------------------------------------------
  Trigger Name : trg_wo_reqcomp_to_stg

  Purpose
  -------
  Propagate changes to a work order�s Required Completion Date
  (REQCOMPDATE_DTTM) down to task-level rows in the
  EPSEWERAI_WOT_STG staging table.

  This trigger recalculates affected task rows by joining back to the
  WORKORDERTASK table in order to identify all tasks belonging to the
  updated work order.

  Triggering Event
  ----------------
  Fires AFTER an UPDATE of the REQCOMPDATE_DTTM column on MNT.WORKORDERS.
  Executes once per updated work order row.

  Data Flow
  ---------
  MNT.WORKORDERS.REQCOMPDATE_DTTM
        ?
  MNT.WORKORDERTASK (task discovery)
        ?
  CUSTOMERDATA.EPSEWERAI_WOT_STG (task staging)

  Functional Behavior
  -------------------
  - Identifies all tasks under the updated work order by querying
    MNT.WORKORDERTASK using WORKORDER_OI.
  - Matches those tasks to existing staging rows using TASK_UUID.
  - Updates the planned completion date and marks rows as UPDATED
    when the value has changed.

  Design Considerations
  ---------------------
  - This trigger does NOT insert new staging rows.
  - Only tasks already present in EPSEWERAI_WOT_STG are affected.
  - Task creation and task attribute changes are handled elsewhere
    by a trigger on MNT.WORKORDERTASK.

  Important Note
  --------------
  This trigger is more complex and tightly coupled than strictly
  necessary because it:
    - Re-queries WORKORDERTASK on every work order date change
    - Uses MERGE instead of a direct UPDATE
    - Depends on task-table joins for a work-order-level change

  A simpler and safer approach is to update staging rows directly
  by WORKORDER_UUID when possible.
----------------------------------------------------------------------------*/
AFTER UPDATE OF REQCOMPDATE_DTTM
ON MNT.WORKORDERS
FOR EACH ROW
BEGIN
  /*--------------------------------------------------------------------------
    Merge staging rows for all tasks belonging to the updated work order.

    Source Query:
    -------------
    - Gathers all task UUIDs under this work order by joining
      to MNT.WORKORDERTASK.
    - Supplies the new required completion date from WORKORDERS.

    Matching Rule:
    --------------
    - Matches staging rows using TASK_UUID.
    - Prevents accidental updates to unrelated tasks.

    Update Behavior:
    ----------------
    - Updates only when the planned completion date has changed
      (NULL-safe comparison).
    - Sets FEED_STATUS to 'UPDATED' to flag downstream processing.
  --------------------------------------------------------------------------*/
  MERGE INTO CUSTOMERDATA.EPSEWERAI_WOT_STG s
  USING (
    SELECT
      t.UUID                   AS task_uuid,
      :NEW.UUID                AS workorder_uuid,
      :NEW.WONUMBER            AS wonumber,
      :NEW.REQCOMPDATE_DTTM    AS plndcompdate_dttm
    FROM MNT.WORKORDERTASK t
    WHERE t.WORKORDER_OI = :NEW.WORKORDERSOI
  ) src
  ON (s.TASK_UUID = src.TASK_UUID)

  WHEN MATCHED THEN
    UPDATE SET
      s.PLNDCOMPDATE_DTTM = src.PLNDCOMPDATE_DTTM,
      s.FEED_STATUS      = 'UPDATED'
    WHERE NVL(s.PLNDCOMPDATE_DTTM, DATE '1900-01-01')
        <> NVL(src.PLNDCOMPDATE_DTTM, DATE '1900-01-01');

  /* No INSERT clause is used.
     Tasks without existing staging rows are intentionally ignored. */
END;
